#include "NamedObject.h"

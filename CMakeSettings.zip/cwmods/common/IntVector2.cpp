#include "IntVector2.h"

IntVector2::IntVector2(int x, int y){
    this->x = x;
    this->y = y;
}

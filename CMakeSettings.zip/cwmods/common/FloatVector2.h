#ifndef COMMON_FLOATVECTOR2_H
#define COMMON_FLOATVECTOR2_H


class FloatVector2 {
    public:
        float x;
		float y;
		FloatVector2(float x, float y);
    };


#endif // COMMON_FLOATVECTOR2_H

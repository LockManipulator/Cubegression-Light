#ifndef COMMON_INTVECTOR3_H
#define COMMON_INTVECTOR3_H


class IntVector3 {
    public:
        int x;
        int y;
        int z;
        IntVector3();
        IntVector3(int x, int y, int z);
    };


#endif // COMMON_INTVECTOR3_H

#ifndef LONGVECTOR3_H
#define LONGVECTOR3_H


class LongVector3 {
    public:
        long long x;
        long long y;
        long long z;
        LongVector3();
        LongVector3(long long x, long long y, long long z);
    };


#endif // LONGVECTOR3_H

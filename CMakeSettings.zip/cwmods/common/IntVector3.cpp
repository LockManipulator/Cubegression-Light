#include "IntVector3.h"

IntVector3::IntVector3(){
    this->x = 0;
    this->y = 0;
    this->z = 0;
}

IntVector3::IntVector3(int x, int y, int z){
    this->x = x;
    this->y = y;
    this->z = z;
}

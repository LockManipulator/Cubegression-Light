#include "LongVector3.h"

LongVector3::LongVector3(){
    this->x = 0;
    this->y = 0;
    this->z = 0;
}

LongVector3::LongVector3(long long x, long long y, long long z){
    this->x = x;
    this->y = y;
    this->z = z;
}

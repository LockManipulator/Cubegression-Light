#ifndef FLOATRGBA_H
#define FLOATRGBA_H


class FloatRGBA {
    public:
        float red;
        float green;
        float blue;
        float alpha;
        FloatRGBA(float red, float green, float blue, float alpha);
    };


#endif // FLOATRGBA_H

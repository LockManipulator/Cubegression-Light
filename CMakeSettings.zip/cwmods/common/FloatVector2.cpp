#include "FloatVector2.h"

FloatVector2::FloatVector2(float x, float y){
    this->x = x;
    this->y = y;
}

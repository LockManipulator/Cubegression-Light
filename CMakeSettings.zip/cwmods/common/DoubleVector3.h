#ifndef COMMON_DOUBLEVECTOR3_H
#define COMMON_DOUBLEVECTOR3_H


class DoubleVector3 {
    public:
        double x;
		double y;
		double z;
		DoubleVector3();
		DoubleVector3(double x, double y, double z);
    };


#endif // COMMON_DOUBLEVECTOR3_H

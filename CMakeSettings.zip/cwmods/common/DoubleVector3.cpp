#include "DoubleVector3.h"

DoubleVector3::DoubleVector3(){
    this->x = 0.0;
    this->y = 0.0;
    this->z = 0.0;
}

DoubleVector3::DoubleVector3(double x, double y, double z){
    this->x = x;
    this->y = y;
    this->z = z;
}

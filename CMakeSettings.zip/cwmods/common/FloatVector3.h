#ifndef FLOATVECTOR3_H
#define FLOATVECTOR3_H


class FloatVector3 {
    public:
        float x;
        float y;
        float z;
        FloatVector3();
        FloatVector3(float x, float y, float z);
    };


#endif // FLOATVECTOR3_H

#ifndef IDA_CONSTANTS_H
#define IDA_CONSTANTS_H

#define _BYTE unsigned char
#define __int64 long long int
#define __int16 short

#endif

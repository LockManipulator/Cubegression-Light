#ifndef D3D11GRAPHICS_H
#define D3D11GRAPHICS_H

#include "../IDA/types.h"

namespace gfx {
class D3D11Graphics {
    public:
        void *vtable;
        __int64 field_8;
        __int64 field_10;
    };
}

#endif // D3D11GRAPHICS_H

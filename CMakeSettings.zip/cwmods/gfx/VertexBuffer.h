#ifndef VERTEXBUFFER_H
#define VERTEXBUFFER_H

#include "../IDA/types.h"

namespace gfx {
class VertexBuffer {
    public:
		~VertexBuffer() {};
    };
}

#endif // VERTEXBUFFER_H

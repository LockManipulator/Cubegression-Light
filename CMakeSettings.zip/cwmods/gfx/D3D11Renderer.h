#ifndef D3D11RENDERER_H
#define D3D11RENDERER_H

#include "../IDA/types.h"

namespace gfx {
class D3D11Renderer {
    public:
        _BYTE gap0[2631];
        char end;
    };
}

#endif // D3D11RENDERER_H

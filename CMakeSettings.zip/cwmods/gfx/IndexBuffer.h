#ifndef INDEXBUFFER_H
#define INDEXBUFFER_H

#include "../IDA/types.h"

namespace gfx {
class IndexBuffer {
    public:
		~IndexBuffer() {};
    };
}

#endif // INDEXBUFFER_H

#ifndef DATABASE_H
#define DATABASE_H

#include "../IDA/types.h"

namespace cube {
    class Database {
        public:
            void *vtable;
            __int64 field_8;
        };
}

#endif // DATABASE_H

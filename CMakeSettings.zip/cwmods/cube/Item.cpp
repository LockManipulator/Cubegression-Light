#include "Item.h"


cube::Item::Item(){
}
cube::Item::Item(char category, int id) {
    this->category = category;
    this->id = id;
}

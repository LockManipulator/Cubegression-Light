namespace cube {
    const int DOTS_PER_BLOCK = 65536;
    const int BLOCKS_PER_MAP_CHUNK = 20;
	const int BLOCKS_PER_ZONE = 64;
}

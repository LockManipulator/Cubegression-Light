#ifndef SPIRIT_H
#define SPIRIT_H

namespace cube {
class Spirit {
    public:
        char x;
        char y;
        char z;
        char material;
    };
}

#endif // SPIRIT_H
